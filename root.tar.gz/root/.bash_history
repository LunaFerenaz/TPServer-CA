history
history -w
rm -f /root/.bash_history
journalctl --rotate
journalctl --vacuum-time=1s
apt clean
sync
poweroff
hostnamect1 set-hostname TPServer
hostnamectl set-hostname TPServer
sed -i s/debian/TPServer/g /etc/hosts
cat /etc/hosts
hostname
ip a
ping -c3 deb.debian.org
cat/etc/network/interfaces
cat /etc/network/interfaces
sed -i s/enp0s3/enp0s1/g /etc/network/interfaces
ifup enp0s1
ip a
apt update
apt install -y openssh-server
echo nameserver 8.8.8.8 > /etc/resolv.conf
ping -c3 deb.debian.org
apt update
sed -i s/cdn2-fastly.deb.debian.org/deb.debian.org/g /etc/apt/sources.list
apt update
apt install -y openssh-server
echo PermitRootLogin yes >> /etc/ssh/sshd_config
systemctl restart ssh
ip a
apt install -y tmux
tmux
tmux attach
cat > /etc/apt/sources.list <<'EOF'
deb http://deb.debian.org/debian bookworm main contrib non-free non-free-firmware
deb http://deb.debian.org/debian bookworm-updates main contrib non-free non-free-firmware
deb http://security.debian.org/debian-security bookworm-security main contrib non-free non-free-firmware
EOF

ls /etc/apt/sources.list.d/
apt update
apt upgrade -y --without-new-pkgs
apt full-upgrade -y
cat /etc/debian_version
grub-install /dev/sda
update-grub
apt autoremove -y
reboot
ip a
ping -c2 192.168.0.50
cat > /etc/network/interfaces <<'EOF'
# The loopback network interface
auto lo
iface lo inet loopback

# The primary network interface
auto enp0s1
iface enp0s1 inet static
    address 192.168.0.50
    netmask 255.255.255.0
    gateway 192.168.0.1
EOF

echo nameserver 8.8.8.8 > /etc/resolv.conf
cat /etc/network/interfaces
reboot
exit
ip a
ping -c3 deb.debian.org
ls -la /root
ls -la /root/.ssh
tar -tzvf /root/Material_Adicional_TPVMCA.tar.gz
cd /root
tar -xzvf Material_Adicional_TPVMCA.tar.gz
cat Material_Adicional_TPVMCA/clave_publica.pub >> /root/.ssh/authorized_keys
chmod 700 /root/.ssh
chmod 600 /root/.ssh/authorized_keys
sed -i '/^PermitRootLogin yes/d' /etc/ssh/sshd_config
echo PermitRootLogin prohibit-password >> /etc/ssh/sshd_config
systemctl restart ssh
grep PermitRootLogin /etc/ssh/sshd_config
apt install -y apache2 php libapache2-mod-php php-mysql
php -v
cat /root/Material_Adicional_TPVMCA/index.php
cp /root/Material_Adicional_TPVMCA/index.php /root/Material_Adicional_TPVMCA/logo.png /var/www/html/
rm -f /var/www/html/index.html
systemctl restart apache2
cp /root/Material_Adicional_TPVMCA/index.php /root/Material_Adicional_TPVMCA/logo.png /var/www/html/
rm -f /var/www/html/index.html
systemctl restart apache2
apt install -y mariadb-server
grep -inE "create|grant|use " /root/Material_Adicional_TPVMCA/db.sql
mysql -u root < /root/Material_Adicional_TPVMCA/db.sql
mysql -u lcars -pNCC1701D ingenieria -e "SELECT COUNT(*) FROM alumnos; SELECT COUNT(*) FROM notas;"
mysql -u root -e "DROP DATABASE ingenieria; DROP USER 'lcars'@'%';"
mysql -u root --default-character-set=utf8mb4 < /root/Material_Adicional_TPVMCA/db.sql
echo "AddDefaultCharset UTF-8" > /etc/apache2/conf-available/charset.conf
systemctl restart apache2
poweroff
lsblk
printf "n\np\n1\n\n+3G\nn\np\n2\n\n+6G\nw\n" | fdisk /dev/sdc
fdisk -l /dev/sdc
mkfs.ext4 -F /dev/sdc1
mkfs.ext4 -F /dev/sdc2
mkdir -p
mkdir -p /www_dir /backup_dir
echo "UUID=$(blkid -s UUID -o value /dev/sdc1)  /www_dir     ext4  defaults  0  2" >> /etc/fstab
echo "UUID=$(blkid -s UUID -o value /dev/sdc2)  /backup_dir  ext4  defaults  0  2" >> /etc/fstab
systemctl daemon-reload
mount -a
tail -2 /etc/fstab
df -h /www_dir /backup_dir
mkdir -p /www_dir /backup_dir
echo "UUID=$(blkid -s UUID -o value /dev/sdc1)  /www_dir     ext4  defaults  0  2" >> /etc/fstab
echo "UUID=$(blkid -s UUID -o value /dev/sdc2)  /backup_dir  ext4  defaults  0  2" >> /etc/fstab
systemctl daemon-reload
mount -a
tail -2 /etc/fstab
df -h /www_dir /backup_dir
grep -c _dir /etc/fstab
  awk '!seen[$0]++' /etc/fstab > /tmp/fstab && cp /tmp/fstab /etc/fstab
  grep -c _dir /etc/fstab
cp /root/Material_Adicional_TPVMCA/index.php /root/Material_Adicional_TPVMCA/logo.png /www_dir/
chown -R www-data:www-data /www_dir
sed -i 's|DocumentRoot /var/www/html|DocumentRoot /www_dir|' /etc/apache2/sites-available/000-default.conf
cat >> /etc/apache2/apache2.conf <<'EOF'

<Directory /www_dir/>
	Options Indexes FollowSymLinks
	AllowOverride None
	Require all granted
</Directory>
EOF

systemctl restart apache2
grep DocumentRoot /etc/apache2/sites-available/000-default.conf
cat /proc/partitions > /opt/particion
cat /opt/particion
reboot
